#!/bin/sh

# scp -r ../src b05902059@linux6.csie.org:./ComputerNetwork/
rm -rf USER
mkdir USER
rm -rf Account
# rm -f Account/account.txt
mkdir Account
touch Account/account.txt